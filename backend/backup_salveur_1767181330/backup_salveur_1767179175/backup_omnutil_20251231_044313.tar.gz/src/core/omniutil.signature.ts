export function omniutilSignature() {
  return {
    poweredBy: "OMNIUTIL",
    protocol: "UNIVERSAL",
    timestamp: new Date().toISOString()
  };
}
