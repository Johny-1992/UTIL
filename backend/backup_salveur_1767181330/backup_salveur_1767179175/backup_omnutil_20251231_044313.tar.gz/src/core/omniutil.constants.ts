export const OMNIUTIL_QR_VERSION = "v1";
export const OMNIUTIL_AUTHOR_SHARE = 0.02;
