export const OMNIUTIL_PROTOCOL = {
  name: "Omniutil",
  version: "1.0.0",
  mode: "REAL",
  automation: "TOTAL",
  logic: "UNIVERSAL_INFRASTRUCTURE"
};
