export default { info: console.log, warn: console.warn, error: console.error };
