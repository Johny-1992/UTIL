import { Contract } from "ethers";

export const getOmniUtilContract = (contract: Contract): any =>
  contract as any;
