export const OMNIUTIL_COPYRIGHT = {
  author: "Original Creator of OMNIUTIL",
  rights: "Perpetual, irrevocable, worldwide",
  enforcement: "Automatic by system design",
  reproduction: "Allowed only with attribution",
  royalty: "Embedded by principle"
};
