export const OMNIUTIL_ROYALTY = {
  model: "Perpetual attribution + value recognition",
  enforcement: "Moral, legal and technical",
  appliesTo: ["partners", "derivatives", "integrations"]
};
