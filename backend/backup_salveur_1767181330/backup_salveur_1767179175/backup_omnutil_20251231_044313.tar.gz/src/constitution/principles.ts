export const OMNIUTIL_PRINCIPLES = [
  "One system, multiple realities (demo + real)",
  "No fork without recognition",
  "No usage without attribution",
  "Evolution without corruption"
];
