"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.computeUTIL = computeUTIL;
function computeUTIL(usage, rate) {
    return usage * rate;
}
