export function computeUTIL(usage: number, rate: number) {
  return usage * rate;
}
