// Simule la récupération du prix de UTIL
export async function getUtilPrice(): Promise<number> {
  return 2.0; // Exemple : 1 UTIL = 2 USDT
}
